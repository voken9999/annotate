"use client"
import { useState } from "react"
import PDFViewer from "@/components/PDFViewer"
import Toolbar from "@/components/Toolbar"
export default function Home(){
 const [file,setFile]=useState<File|null>(null)
 return <main><Toolbar />{!file?<input type="file" accept=".pdf" onChange={(e)=>e.target.files?.[0]&&setFile(e.target.files[0])}/>:<PDFViewer file={file}/>}</main>
}